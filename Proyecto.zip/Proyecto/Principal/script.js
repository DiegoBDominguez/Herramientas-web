
function Buscar(){

  let opc = document.getElementById("opc").value;

  if(opc == 1){
    var nombre1 = localStorage.getItem("Nombre1a");
    var nombre2 = localStorage.getItem("Nombre1b");
    var comentario1 = localStorage.getItem("Comentario1a");
    var comentario2 = localStorage.getItem("Comentario1b");
    document.getElementById("titulo").innerHTML = "Primavera de arte y cultura";
    document.getElementById("contenido").innerHTML = "Te invitamos a disfrutar de una primavera diferente, lleno de arte y cultura con presentaciones de danza, teatro, música, exposiciones, performance y muchas más sorpresas que tenemos para ti de forma totalmente gratuita.";
    document.getElementById("fecha").innerHTML = "Jueves 04 de Mayo de 2023";
    document.getElementById("nom1").innerHTML = "Pedro ";
    document.getElementById("com1").innerHTML = "Es muy increible, vale totalmente la pena asistir";
    document.getElementById("nom2").innerHTML = "Jose Pablo ";
    document.getElementById("com2").innerHTML = "Recomiendo ir con tu familia para disfrutar el evento mejor";
    document.getElementById("nom3").innerHTML = nombre1;
    document.getElementById("com3").innerHTML = comentario1;
    document.getElementById("nom3").innerHTML = nombre2;
    document.getElementById("com3").innerHTML = comentario2;
    document.getElementById("ubicacion").innerHTML = "Puebla";
    document.getElementById("foto").src = "evento1.jpg";

  }
  else if(opc == 2){
    var nombre1 = localStorage.getItem("Nombre2a");
    var nombre2 = localStorage.getItem("Nombre2b");
    var comentario1 = localStorage.getItem("Comentario2a");
    var comentario2 = localStorage.getItem("Comentario2b");
    document.getElementById("titulo").innerHTML = "Carnaval Huejotzingo";
    document.getElementById("contenido").innerHTML = "El municipio de Huejotzingo, te espera para disfrutar de una de sus más bellas tradiciones; el Carnaval de Huejotzingo 2023, éste gran evento se llevará a cabo del 18 al 21 de febrero de 2023.";
    document.getElementById("fecha").innerHTML = "18 de febrero de 2023";
    document.getElementById("nom1").innerHTML = "Garcia ";
    document.getElementById("com1").innerHTML = "Es una experiencia inolvidable, no falten ";
    document.getElementById("nom2").innerHTML = "Jose";
    document.getElementById("com2").innerHTML = "Recomiendo ir con tu familia para disfrutar el evento mejor";
    document.getElementById("nom3").innerHTML = nombre1;
    document.getElementById("com3").innerHTML = comentario1;
    document.getElementById("nom4").innerHTML = nombre2;
    document.getElementById("com4").innerHTML = comentario2;
    document.getElementById("ubicacion").innerHTML = "Huejotzingo";
    document.getElementById("foto").src = "evento2a.jpg";


  }
  else if(opc == 3){
    var nombre1 = localStorage.getItem("Nombre3a");
    var nombre2 = localStorage.getItem("Nombre3b");
    var comentario1 = localStorage.getItem("Comentario3a");
    var comentario2 = localStorage.getItem("Comentario3b");
    document.getElementById("titulo").innerHTML = "Feria de los Muertos ";
    document.getElementById("contenido").innerHTML = "La segunda edición de la Feria de los Muertos llega a Zacatlán para acercar a todos los turistas las tradiciones que existen en este Pueblo Mágico inmerso en la Sierra Norte de Puebla. " ;
    document.getElementById("fecha").innerHTML = "28 de octubre 2023 ";
    document.getElementById("nom1").innerHTML = "Juanito";
    document.getElementById("com1").innerHTML = "Esta muy bien organizado";
    document.getElementById("nom2").innerHTML = "Pedro";
    document.getElementById("com2").innerHTML = "No recomiendo perderselo para nada";
    document.getElementById("nom3").innerHTML =  nombre1;
    document.getElementById("com3").innerHTML = comentario1;
    document.getElementById("nom4").innerHTML = nombre2;
    document.getElementById("com4").innerHTML = comentario2;
    document.getElementById("ubicacion").innerHTML = "Zacatlán";
    document.getElementById("foto").src = "Sitio3.jfif";


  }
  else if(opc == 4){
    var nombre1 = localStorage.getItem("Nombre4a");
    var nombre2 = localStorage.getItem("Nombre4b");
    var comentario1 = localStorage.getItem("Comentario4a");
    var comentario2 = localStorage.getItem("Comentario4b");
    document.getElementById("titulo").innerHTML = "Feria Nacional del Árbol y la Esfera ";
    document.getElementById("contenido").innerHTML = "Es una de las ferias más tradicionales para comprar variados adornos navideños artesanales, en un ambiente de fiesta y espectáculos artísticos, no olvides que el 1 de Noviembre Día de Muertos, se lleva a cabo el Festival Nocturno de la Luz y de la Vida, que como cada año se realiza en la laguna de Chignahuapan.";
    document.getElementById("fecha").innerHTML = "25 de noviembre de 2023";
    document.getElementById("nom1").innerHTML = "Pepe";
    document.getElementById("com1").innerHTML = "Recomiendo llevar chamarra para el frio ";
    document.getElementById("nom2").innerHTML = "Diego ";
    document.getElementById("com2").innerHTML = "Vayan temprano para encontrar lugar  ";
    document.getElementById("nom3").innerHTML = nombre1;
    document.getElementById("com3").innerHTML = comentario1;
    document.getElementById("nom4").innerHTML = nombre2;
    document.getElementById("com4").innerHTML = comentario2;
    document.getElementById("ubicacion").innerHTML = "Chignahuapan";
    document.getElementById("foto").src = "evento4.jpg";


  }
  else if(opc == 5){
    var nombre1 = localStorage.getItem("Nombre5a");
    var nombre2 = localStorage.getItem("Nombre5b");
    var comentario1 = localStorage.getItem("Comentario5a");
    var comentario2 = localStorage.getItem("Comentario5b");
    document.getElementById("titulo").innerHTML = "Festival de la Luz y la Vida ";
    document.getElementById("contenido").innerHTML = "Un recorrido nocturno que guía hacia la laguna, iluminado por las antorchas de miles de peregrinos, es como da inicio el “Festival de la Luz y la Vida” en Chignahuapan, una representación prehispánica sobre el viaje de las almas a través de los nueve infiernos del Mictlán.  ";
    document.getElementById("fecha").innerHTML = "29 de noviembre de 2023";
    document.getElementById("nom1").innerHTML = "Antonio";
    document.getElementById("com1").innerHTML = "Es realimente fantastico ";
    document.getElementById("nom2").innerHTML = "Ricardo";
    document.getElementById("com2").innerHTML = "Recomiendo ir con tu familia para disfrutar el evento mejor";
    document.getElementById("nom3").innerHTML = nombre1;
    document.getElementById("com3").innerHTML = comentario1;
    document.getElementById("nom4").innerHTML = nombre2;
    document.getElementById("com4").innerHTML = comentario2;
    document.getElementById("ubicacion").innerHTML = "Chignahuapan";
    document.getElementById("foto").src = "evento44.jpg";


  }
  else if(opc == 6){
    var nombre1 = localStorage.getItem("Nombre6a");
    var nombre2 = localStorage.getItem("Nombre6b");
    var comentario1 = localStorage.getItem("Comentario6a");
    var comentario2 = localStorage.getItem("Comentario6b");
    document.getElementById("titulo").innerHTML = "Festival Cultural de la Sierra  ";
    document.getElementById("contenido").innerHTML = "Este evento se llevará a cabo del 02 al 09 de abril en dicha demarcación Contempla actividades de artesanías, literatura, danza, teatro, rituales y el tradicional “Jueves de huapango”";
    document.getElementById("fecha").innerHTML = "2 de abril de 2023";
    document.getElementById("nom1").innerHTML = "Garcia";
    document.getElementById("com1").innerHTML = "Es una experiencia inolvidable, no falten";
    document.getElementById("nom2").innerHTML = "Jose";
    document.getElementById("com2").innerHTML = "Recomiendo ir con tu familia para disfrutar el evento mejor";
    document.getElementById("nom3").innerHTML = nombre1;
    document.getElementById("com3").innerHTML = comentario1;
    document.getElementById("nom4").innerHTML = nombre2;
    document.getElementById("com4").innerHTML = comentario2;
    document.getElementById("ubicacion").innerHTML = "Pahuatlán	";
    document.getElementById("foto").src = "evento6.png";


  }
  else if(opc == 7){
    var nombre1 = localStorage.getItem("Nombre7a");
    var nombre2 = localStorage.getItem("Nombre7b");
    var comentario1 = localStorage.getItem("Comentario7a");
    var comentario2 = localStorage.getItem("Comentario7b");
    document.getElementById("titulo").innerHTML = "Festival Ciudad Mural Puebla  ";
    document.getElementById("contenido").innerHTML = "Festival Ciudad Mural Puebla fue traído a la ciudad por el programa de impacto social Comex por un México Bien Hecho y Colectivo Tomate a través del Programa de Festivales Culturales y Artísticos";
    document.getElementById("fecha").innerHTML = "1 de octubre de 2023";
    document.getElementById("nom1").innerHTML = "Garcia";
    document.getElementById("com1").innerHTML = "Es una experiencia inolvidable, no falten";
    document.getElementById("nom2").innerHTML = "Jose";
    document.getElementById("com2").innerHTML = "Recomiendo ir con tu familia para disfrutar el evento mejor";
    document.getElementById("nom3").innerHTML = nombre1;
    document.getElementById("com3").innerHTML = comentario1;
    document.getElementById("nom4").innerHTML = nombre2;
    document.getElementById("com4").innerHTML = comentario2;
    document.getElementById("ubicacion").innerHTML = "Puebla";
    document.getElementById("foto").src = "evento7.jpg";


  }
  else if(opc == 8){
    var nombre1 = localStorage.getItem("Nombre8a");
    var nombre2 = localStorage.getItem("Nombre8b");
    var comentario1 = localStorage.getItem("Comentario8a");
    var comentario2 = localStorage.getItem("Comentario8b");
    document.getElementById("titulo").innerHTML = "Villa ilimunada ";
    document.getElementById("contenido").innerHTML = "Ven a vivir la Magia de La Navidad a “La Villa Iluminada” más grande de México. Con ello Experimenta la sensación de visitar un Pueblo Mágico Navideño con figuras alusivas a la temporada navideña llenas de luces y colores. ";
    document.getElementById("fecha").innerHTML = "21 de octubre de 2023";
    document.getElementById("nom1").innerHTML = "Garcia";
    document.getElementById("com1").innerHTML = "Es una experiencia inolvidable, no falten<";
    document.getElementById("nom2").innerHTML = "Jose";
    document.getElementById("com2").innerHTML = "Recomiendo ir con tu familia para disfrutar el evento mejor";
    document.getElementById("nom3").innerHTML = nombre1;
    document.getElementById("com3").innerHTML = comentario1;
    document.getElementById("nom4").innerHTML = nombre2;
    document.getElementById("com4").innerHTML = comentario2;
    document.getElementById("ubicacion").innerHTML = "Puebla";
    document.getElementById("foto").src = "evento8.jpg.png";


  }
  else if(opc == 9){
    var nombre1 = localStorage.getItem("Nombre9a");
    var nombre2 = localStorage.getItem("Nombre9b");
    var comentario1 = localStorage.getItem("Comentario9a");
    var comentario2 = localStorage.getItem("Comentario9b");
    document.getElementById("titulo").innerHTML = "TECALI DE HERRERA ";
    document.getElementById("contenido").innerHTML = "Trajes tradicionales llenos de brillos, gritos, colores, plumas, música, carros alegóricos y grandes danzas por las calles, es como se celebra el carnaval de Tecali de Herrera.    ";
    document.getElementById("fecha").innerHTML = " 27 de febrero 2023";
    document.getElementById("nom1").innerHTML = "Garcia ";
    document.getElementById("com1").innerHTML = "Es una experiencia inolvidable, no falten ";
    document.getElementById("nom2").innerHTML = "Jose ";
    document.getElementById("com2").innerHTML = "Recomiendo ir con tu familia para disfrutar el evento mejor ";
    document.getElementById("nom3").innerHTML = nombre1;
    document.getElementById("com3").innerHTML = comentario1;
    document.getElementById("nom4").innerHTML = nombre2;
    document.getElementById("com4").innerHTML = comentario2;
    document.getElementById("ubicacion").innerHTML = "Puebla";
    document.getElementById("foto").src = "car.jpg";


  }
  else if(opc == 10){
    var nombre1 = localStorage.getItem("Nombre10a");
    var nombre2 = localStorage.getItem("Nombre10b");
    var comentario1 = localStorage.getItem("Comentario10a");
    var comentario2 = localStorage.getItem("Comentario10b");
    document.getElementById("titulo").innerHTML = "SANTA RITA TLAHUAPAN";
    document.getElementById("contenido").innerHTML = "Santa Rita Tlahuapan es una localidad mexicana cabecera del municipio de Tlahuapan que pertenece a su vez al estado de Puebla. En este lugar se dedican sus pobladores principalmente a la agricultura y ganadería.";
    document.getElementById("fecha").innerHTML = "22 de mayo de 2023";
    document.getElementById("nom1").innerHTML = "Antonio";
    document.getElementById("com1").innerHTML = "Es realimente fantastico";
    document.getElementById("nom2").innerHTML = "Ricardo";
    document.getElementById("com2").innerHTML = "No recomiendo perderselo para nada";
    document.getElementById("nom3").innerHTML = nombre1;
    document.getElementById("com3").innerHTML = comentario1;
    document.getElementById("nom4").innerHTML = nombre2;
    document.getElementById("com4").innerHTML = comentario2;
    document.getElementById("ubicacion").innerHTML = "TLAHUAPAN ";
    document.getElementById("foto").src = "l.jpg";


  }

  }


    
    let cont1,cont2,cont3,cont4,cont5,cont6,cont7,cont8,cont9,cont10 ;

    
     cont1 = 0;
    function Guardar1(){

      cont1 = cont1 + 1;
     let  a1 = document.getElementById("E1A").value;
     let  b1 = document.getElementById("E1B").value;

     if(cont1 == 1){
      document.getElementById("com1a").innerHTML = a1 ;
      document.getElementById("tex1a").innerHTML = b1 ;
      localStorage.setItem("Nombre1a", a1);
      localStorage.setItem("Comentario1a", b1);
     }
     else if (cont1 == 2){
      
      document.getElementById("com1b").innerHTML = a1 ;
      document.getElementById("tex1b").innerHTML = b1 ;
      localStorage.setItem("Nombre1b", a1);
      localStorage.setItem("Comentario1b", b1);
      
     }

    }



    cont2 = 0;
     function Guardar2(){

      cont2 = cont2 + 1;
     let  a1 = document.getElementById("E2A").value;
     let  b1 = document.getElementById("E2B").value;

     if(cont2 == 1){
      document.getElementById("com2a").innerHTML = a1 ;
      document.getElementById("tex2a").innerHTML = b1 ;
      localStorage.setItem("Nombre2a", a1);
      localStorage.setItem("Comentario2a", b1);
     }
     else if (cont2 == 2){
      document.getElementById("com2b").innerHTML = a1 ;
      document.getElementById("tex2b").innerHTML = b1 ;
      localStorage.setItem("Nombre2b", a1);
      localStorage.setItem("Comentario2b", b1);
      
     }



    }

    cont3 = 0;
    function Guardar3(){

      cont3 = cont3 + 1;
     let  a1 = document.getElementById("E3A").value;
     let  b1 = document.getElementById("E3B").value;

     if(cont3 == 1){
      document.getElementById("com3a").innerHTML = a1 ;
      document.getElementById("tex3a").innerHTML = b1 ;
      localStorage.setItem("Nombre3a", a1);
      localStorage.setItem("Comentario3a", b1);
     }
     else if (cont3 == 2){
      document.getElementById("com3b").innerHTML = a1 ;
      document.getElementById("tex3b").innerHTML = b1 ;
      localStorage.setItem("Nombre3b", a1);
      localStorage.setItem("Comentario3b", b1);
      
     }

    }

    cont4 = 0;
    function Guardar4(){

      cont4 = cont4 + 1;
     let  a1 = document.getElementById("E4A").value;
     let  b1 = document.getElementById("E4B").value;

     if(cont4 == 1){
      document.getElementById("com4a").innerHTML = a1 ;
      document.getElementById("tex4a").innerHTML = b1 ;
      localStorage.setItem("Nombre4a", a1);
      localStorage.setItem("Comentario4a", b1);
     }
     else if (cont4 == 2){
      document.getElementById("com4b").innerHTML = a1 ;
      document.getElementById("tex4b").innerHTML = b1 ;
      localStorage.setItem("Nombre4b", a1);
      localStorage.setItem("Comentario4b", b1);
      
     }

    }

    cont5 = 0;
    function Guardar5(){

      cont5 = cont5 + 1;
     let  a1 = document.getElementById("E5A").value;
     let  b1 = document.getElementById("E5B").value;

     if(cont5 == 1){
      document.getElementById("com5a").innerHTML = a1 ;
      document.getElementById("tex5a").innerHTML = b1 ;
      localStorage.setItem("Nombre5a", a1);
      localStorage.setItem("Comentario5a", b1);
     }
     else if (cont5 == 2){
      document.getElementById("com5b").innerHTML = a1 ;
      document.getElementById("tex5b").innerHTML = b1 ;
      localStorage.setItem("Nombre5b", a1);
      localStorage.setItem("Comentario5b", b1);
      
     }

    }

    cont6 = 0;
    function Guardar6(){

      cont6 = cont6 + 1;
     let  a1 = document.getElementById("E6A").value;
     let  b1 = document.getElementById("E6B").value;

     if(cont6 == 1){
      document.getElementById("com6a").innerHTML = a1 ;
      document.getElementById("tex6a").innerHTML = b1 ;
      localStorage.setItem("Nombre6a", a1);
      localStorage.setItem("Comentario6a", b1);
     }
     else if (cont6 == 2){
      document.getElementById("com6b").innerHTML = a1 ;
      document.getElementById("tex6b").innerHTML = b1 ;
      localStorage.setItem("Nombre6b", a1);
      localStorage.setItem("Comentario6b", b1);
      
     }

    }

    cont7 = 0;
    function Guardar7(){

      cont7 = cont7 + 1;
     let  a1 = document.getElementById("E7A").value;
     let  b1 = document.getElementById("E7B").value;

     if(cont7 == 1){
      document.getElementById("com7a").innerHTML = a1 ;
      document.getElementById("tex7a").innerHTML = b1 ;
      localStorage.setItem("Nombre7a", a1);
      localStorage.setItem("Comentario7a", b1);
     }
     else if (cont7 == 2){
      document.getElementById("com7b").innerHTML = a1 ;
      document.getElementById("tex7b").innerHTML = b1 ;
      localStorage.setItem("Nombre7b", a1);
      localStorage.setItem("Comentario7b", b1);
      
     }

    }


    cont8 = 0;
    function Guardar8(){

      cont8 = cont8 + 1;
     let  a1 = document.getElementById("E8A").value;
     let  b1 = document.getElementById("E8B").value;

     if(cont8 == 1){
      document.getElementById("com8a").innerHTML = a1 ;
      document.getElementById("tex8a").innerHTML = b1 ;
      localStorage.setItem("Nombre8a", a1);
      localStorage.setItem("Comentario8a", b1);
     }
     else if (cont8 == 2){
      document.getElementById("com8b").innerHTML = a1 ;
      document.getElementById("tex8b").innerHTML = b1 ;
      localStorage.setItem("Nombre8b", a1);
      localStorage.setItem("Comentario8b", b1);
      
     }

    }

    cont9 = 0;
    function Guardar9(){

      cont9 = cont9 + 1;
     let  a1 = document.getElementById("E9A").value;
     let  b1 = document.getElementById("E9B").value;

     if(cont9 == 1){
      document.getElementById("com9a").innerHTML = a1 ;
      document.getElementById("tex9a").innerHTML = b1 ;
      localStorage.setItem("Nombre9a", a1);
      localStorage.setItem("Comentario9a", b1);
     }
     else if (cont9 == 2){
      document.getElementById("com9b").innerHTML = a1 ;
      document.getElementById("tex9b").innerHTML = b1 ;
      localStorage.setItem("Nombre9b", a1);
      localStorage.setItem("Comentario9b", b1);
      
     }

    }

    cont10 = 0;
    function Guardar10(){

      cont10 = cont10 + 1;
     let  a1 = document.getElementById("E10A").value;
     let  b1 = document.getElementById("E10B").value;

     if(cont10 == 1){
      document.getElementById("com10a").innerHTML = a1 ;
      document.getElementById("tex10a").innerHTML = b1 ;
      localStorage.setItem("Nombre10a", a1);
      localStorage.setItem("Comentario10a", b1);
     }
     else if (cont10 == 2){
      document.getElementById("com10b").innerHTML = a1 ;
      document.getElementById("tex10b").innerHTML = b1 ;
      localStorage.setItem("Nombre10b", a1);
      localStorage.setItem("Comentario10b", b1);
      
     }

    }


    
    // Array de eventos (puedes agregar más eventos aquí)
     var eventos = [
        { fecha: '2023-05-24', nombre: 'Evento 1' },
        { fecha: '2023-05-25', nombre: 'Evento 2' },
        { fecha: '2023-05-26', nombre: 'Evento 3' }
      ];
      
      // Función para agregar los eventos al calendario
      function agregarEventos() {
        var calendar = document.getElementById('event-calendar');
        
        for (var i = 0; i < eventos.length; i++) {
          var row = calendar.insertRow(i + 1);
          var fechaCell = row.insertCell(0);
          var eventoCell = row.insertCell(1);
          
          fechaCell.innerHTML = eventos[i].fecha;
          eventoCell.innerHTML = eventos[i].nombre;
        }
      }
      
      // Llama a la función para agregar los eventos al cargar la página
      window.onload = agregarEventos;
         // Objeto con la agenda de eventos para mayo
      var agenda = {
        "02-2023": [
            { hora: "17:00", evento: "Carnaval Huejotzingo", ubicacion: "Huejotzingo", imagen: "evento2.jpg" },
            { hora: "17:00", evento: "Tecali DE Herreraa ", ubicacion: "Puebla ", imagen: "car.jpg" },
        ],
        "04-2023": [
            { hora: "10:00", evento: "Festival Cultural de la Sierra", ubicacion: "Pahuatlán", imagen: "evento6.png" }
        ],
        
        "05-2023": [
          { hora: "10:00", evento: "Primavera de arte y cultura", ubicacion: "Puebla", imagen: "evento1.jpg" },
          { hora: "15:00", evento: "Santa Rita Tlahuapan", ubicacion: "Puebla", imagen: "l.jpg" }
        ],
        "09-2023": [
            { hora: "12:00", evento: "Festival Ciudad Mural Puebla", ubicacion: "Puebla", imagen: "evento7.jpg" }
          ],
        "10-2023":[
            {hora: "17:00", evento: "Villa ilimunada", ubicacion: "Puebla" , imagen:"evento8.jpg.png"}
        ],
          "11-2023": [
          { hora: "20:00", evento: "Feria de los muertos", ubicacion: "Zacatlán", imagen: "evento3.jpg" },
          { hora: "22:00", evento: "Feria Nacional del Árbol y la Esfera", ubicacion: "Chignahuapan", imagen: "evento4.jpg" },
          { hora: "19:00", evento: "Festival de la Luz y la Vida", ubicacion: "Chignahuapan", imagen: "evento5.jfif" }
      
        ],
        // ... Agrega más eventos aquí ...
      };
  
      
      // Función para buscar eventos por mes
function buscarEventos() {
    // Obtener el valor del campo de entrada de mes
    var mesInput = document.getElementById("mes").value;
  
    // Validar que se haya ingresado un mes válido
    if (mesInput.length !== 2 || isNaN(mesInput)) {
      alert("Por favor, ingresa un mes válido en formato MM");
      return;
    }
  
    // Formatear el mes para que tenga dos dígitos
    var mes = mesInput.padStart(2, "0");
  
    // Filtrar los eventos por mes
    var eventosPorMes = Object.entries(agenda).filter(([fecha]) => fecha.startsWith(mes));
  
    // Mostrar los eventos encontrados
    if (eventosPorMes.length > 0) {
      // Borrar los eventos anteriores, si los hay
      var tabla = document.getElementById("event-agenda");
      tabla.innerHTML = "";
  
      // Crear filas y celdas para los eventos encontrados
      for (var i = 0; i < eventosPorMes.length; i++) {
        var fecha = eventosPorMes[i][0];
        var eventos = eventosPorMes[i][1];
  
        for (var j = 0; j < eventos.length; j++) {
          var hora = eventos[j].hora;
          var evento = eventos[j].evento;
          var ubicacion = eventos[j].ubicacion;
          var imagen = eventos[j].imagen;
  
          // Crear una nueva fila en la tabla
          var fila = tabla.insertRow();
  
          // Crear las celdas para cada dato del evento
          var celdaFecha = fila.insertCell();
          var celdaHora = fila.insertCell();
          var celdaEvento = fila.insertCell();
          var celdaUbicacion = fila.insertCell();
          var celdaImagen = fila.insertCell();
  
          // Asignar los valores a las celdas
          celdaFecha.textContent = fecha;
          celdaHora.textContent = hora;
          celdaEvento.textContent = evento;
          celdaUbicacion.textContent = ubicacion;
  
          // Crear la etiqueta de imagen y asignar el src
          var imagenEvento = document.createElement("img");
          imagenEvento.src = imagen;
          imagenEvento.className = "event-image";
          imagenEvento.style.width = '100px'; // Establecer el ancho deseado de la imagen

  
          // Agregar la imagen a la celda de imagen
          celdaImagen.appendChild(imagenEvento);
        }
      }
    } else {
      // No se encontraron eventos para el mes especificado
      alert("No se encontraron eventos para el mes especificado.");
    }
  }
  // Función para agregar los eventos a la agenda
      function agregarEventos() {
        var agendaTable = document.getElementById('event-agenda');
        
        for (var fecha in agenda) {
          if (agenda.hasOwnProperty(fecha)) {
            var eventos = agenda[fecha];
            
            for (var i = 0; i < eventos.length; i++) {
              var row = agendaTable.insertRow(-1);
              var fechaCell = row.insertCell(0);
              var horaCell = row.insertCell(1);
              var eventoCell = row.insertCell(2);
              var ubicacionCell = row.insertCell(3);
              var imagenCell = row.insertCell(4);
              
              fechaCell.innerHTML = fecha;
              horaCell.innerHTML = eventos[i].hora;
              eventoCell.innerHTML = eventos[i].evento;
              ubicacionCell.innerHTML = eventos[i].ubicacion;
              
              // Crear elemento <img> para mostrar la imagen pequeña
              var imagen = document.createElement('img');
              imagen.src = eventos[i].imagen;
              imagen.style.width = '50px'; // Establecer el ancho deseado de la imagen
              imagenCell.appendChild(imagen);
            }
          }
        }
      }
      
      // Llama a la función para agregar los eventos al cargar la página
      window.onload = agregarEventos;
  
      function validarFormulario() {
          var nombre = document.getElementById("nombre").value;
          var email = document.getElementById("email").value;
          var comentario = document.getElementById("comentario").value;
  
          if (nombre === "" || email === "" || comentario === "") {
              alert("Por favor, complete todos los campos.");
              return false;
          }
  
          // Agregar comentario al contenedor
          var contenedorComentarios = document.getElementById("contenedor-comentarios");
          var nuevoComentario = document.createElement("p");
          nuevoComentario.innerHTML = "<strong>" + nombre + "</strong>: " + comentario;
          contenedorComentarios.appendChild(nuevoComentario);
  
          return true;
      }
      